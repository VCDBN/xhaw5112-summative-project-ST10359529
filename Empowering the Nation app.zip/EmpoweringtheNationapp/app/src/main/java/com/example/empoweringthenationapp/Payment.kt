package com.example.empoweringthenationapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import models.Course

class Payment : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        drawerLayout = findViewById(R.id.my_drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val selectedCourses = intent.getParcelableArrayListExtra<Course>("selectedCourses")

        val totalPrice = selectedCourses?.sumByDouble { it.price } ?: 0.0

        val discountPercentage = when (selectedCourses?.size ?: 0) {
            2 -> 0.05
            3 -> 0.1
            else -> 0.15
        }

        val discountAmount = totalPrice * discountPercentage

        val vat = 0.15 // 15% VAT
        val vatAmount = totalPrice * vat

        val finalTotal = totalPrice - discountAmount + vatAmount

        val tvDiscount = findViewById<TextView>(R.id.tvDiscount)
        tvDiscount.text = "Discount: ${String.format("%.2f%%", discountPercentage * 100)}"

        val tvTotal = findViewById<TextView>(R.id.tvTotal)
        tvTotal.text = "Total (with VAT and discount): $finalTotal"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}