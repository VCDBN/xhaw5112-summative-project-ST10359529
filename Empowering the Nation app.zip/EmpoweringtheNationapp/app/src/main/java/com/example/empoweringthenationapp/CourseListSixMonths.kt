package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import models.Course

class CourseListSixMonths : AppCompatActivity() {

    private val selectedCourses = mutableListOf<Course>()

    private val availableCourses = listOf(
        Course("First Aid", 1500.0),
        Course("Sewing", 1500.0),
        Course("Landscaping", 1500.0),
        Course("Life skills", 1500.0),
    )

    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_list_six_months)

        drawerLayout = findViewById(R.id.my_drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var course1CheckBox = findViewById<CheckBox>(R.id.course1CheckBox)
        var course2CheckBox = findViewById<CheckBox>(R.id.course2CheckBox)
        var course3CheckBox = findViewById<CheckBox>(R.id.course3CheckBox)
        var course4CheckBox = findViewById<CheckBox>(R.id.course4CheckBox)
        var tvReadMore1 = findViewById<TextView>(R.id.tvReadMore1)
        var tvReadMore2 = findViewById<TextView>(R.id.tvReadMore2)
        var tvReadMore3 = findViewById<TextView>(R.id.tvReadMore3)
        var tvReadMore4 = findViewById<TextView>(R.id.tvReadMore4)

        btnSubmit.setOnClickListener {

            if (selectedCourses.isEmpty()) {
                // No courses are selected; show an error message.
                Toast.makeText(this, "Please select at least one course.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, ContactConsultant::class.java)
                startActivity(intent)
            }
        }

        tvReadMore1.setOnClickListener {
            val intent = Intent(this, FirstAid::class.java)
            startActivity(intent)
        }

        tvReadMore2.setOnClickListener {
            val intent = Intent(this, Sewing::class.java)
            startActivity(intent)
        }

        tvReadMore3.setOnClickListener {
            val intent = Intent(this, Landscaping::class.java)
            startActivity(intent)
        }

        tvReadMore4.setOnClickListener {
            val intent = Intent(this, LifeSkills::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }

    private fun moveToPaymentPage() {
        // Pass the list of selected courses to the Payment page
        val intent = Intent(this, Payment::class.java)
        intent.putParcelableArrayListExtra("selectedCourses", ArrayList(selectedCourses))
        startActivity(intent)
    }
}