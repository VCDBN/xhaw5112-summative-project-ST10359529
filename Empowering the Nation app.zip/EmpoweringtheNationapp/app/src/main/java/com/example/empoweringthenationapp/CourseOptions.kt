package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout

class CourseOptions : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_options)

        drawerLayout = findViewById(R.id.my_drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var timeframeRadioGroup = findViewById<RadioGroup>(R.id.timeframeRadioGroup)
        var sixMonthsRadioButton = findViewById<RadioButton>(R.id.sixMonthsRadioButton)
        var sixWeeksRadioButton = findViewById<RadioButton>(R.id.sixWeeksRadioButton)
        var tvBack = findViewById<TextView>(R.id.tvBack)

        val image = findViewById<ImageView>(R.id.imageView3)
        image.setImageResource(R.drawable.img)

        btnSubmit.setOnClickListener {

            val selectedRadioButtonId = timeframeRadioGroup.checkedRadioButtonId
            if (selectedRadioButtonId == sixMonthsRadioButton.id) {
                // The "6 Months" option is selected; navigate to the "CourseList" page.
                val intent = Intent(this, CourseListSixMonths::class.java)
                startActivity(intent)
            } else  if (selectedRadioButtonId == sixWeeksRadioButton.id){
                val intent = Intent(this, CourseListSixWeeks::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please select a timeframe", Toast.LENGTH_SHORT).show()
            }
        }

        tvBack.setOnClickListener {
            val intent = Intent(this, HomePage::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}