package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import models.Course

class CourseListSixWeeks : AppCompatActivity() {

    private val selectedCourses = mutableListOf<Course>()

    private val availableCourses = listOf(
        Course("Child minding", 750.0),
        Course("Cooking", 750.0),
        Course("Garden Maintenance", 750.0),
    )

    var course1CheckBox = findViewById<CheckBox>(R.id.course1CheckBox)
    var course2CheckBox = findViewById<CheckBox>(R.id.course2CheckBox)
    var course3CheckBox = findViewById<CheckBox>(R.id.course3CheckBox)

    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_list_six_weeks)

        drawerLayout = findViewById(R.id.my_drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        var btnSubmit = findViewById<Button>(R.id.btnSubmit)
        var tvReadMore1 = findViewById<TextView>(R.id.tvReadMore1)
        var tvReadMore2 = findViewById<TextView>(R.id.tvReadMore2)
        var tvReadMore3 = findViewById<TextView>(R.id.tvReadMore3)

        btnSubmit.setOnClickListener {

            if (selectedCourses.isEmpty()) {
                // No courses are selected; show an error message.
                Toast.makeText(this, "Please select at least one course.", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, ContactConsultant::class.java)
                startActivity(intent)
            }
        }



        tvReadMore1.setOnClickListener {
            val intent = Intent(this, ChildMinding::class.java)
            startActivity(intent)
        }

        tvReadMore2.setOnClickListener {
            val intent = Intent(this, Cooking::class.java)
            startActivity(intent)
        }

        tvReadMore3.setOnClickListener {
            val intent = Intent(this, GardenMaintenance::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }



    private fun moveToPaymentPage() {
        // Pass the list of selected courses to the Payment page
        val intent = Intent(this, Payment::class.java)
        intent.putParcelableArrayListExtra("selectedCourses", ArrayList(selectedCourses))
        startActivity(intent)
    }
}