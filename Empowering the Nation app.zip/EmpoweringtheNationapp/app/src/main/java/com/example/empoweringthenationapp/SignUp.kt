package com.example.empoweringthenationapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        var btnSignUp = findViewById<Button>(R.id.btnSignUp)

        var edtEmail = findViewById<EditText>(R.id.edtEmail)

        var edtPassword = findViewById<EditText>(R.id.edtPassword)

        var edtConfirmPassword = findViewById<EditText>(R.id.edtConfirmPassword)

        val image = findViewById<ImageView>(R.id.imageView)
        image.setImageResource(R.drawable.img)

        btnSignUp.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()
            val confirmPassword = edtConfirmPassword.text.toString()

            if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                // Show an error message if any field is empty
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else if (password != confirmPassword) {
                // Show an error message if passwords do not match
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else if (password == confirmPassword){
                // All fields are filled, and passwords match; you can proceed to the next page
                val intent = Intent(this, HomePage::class.java)
                startActivity(intent)
            }
        }
    }
}